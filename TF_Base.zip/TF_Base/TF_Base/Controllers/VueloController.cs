﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TF_Base.Models;

namespace TF_Base.Controllers
{
    public class VueloController : Controller
    {
        private SistemaVuelosBDEntities db = new SistemaVuelosBDEntities();

        //
        // GET: /Vuelo/

        public ActionResult Index()
        {
            var vuelo = db.Vuelo.Include(v => v.Conexiones);
            return View(vuelo.ToList());
        }

        //
        // GET: /Vuelo/Details/5

        public ActionResult Details(int id = 0)
        {
            Vuelo vuelo = db.Vuelo.Find(id);
            if (vuelo == null)
            {
                return HttpNotFound();
            }
            return View(vuelo);
        }

        //
        // GET: /Vuelo/Create

        public ActionResult Create()
        {
            ViewBag.ConexionID = new SelectList(db.Conexiones, "ConexionID", "VerInfoCompleta");//fijarse ""
            return View();
        }

        //
        // POST: /Vuelo/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Vuelo vuelo)
        {
            string id = db.Conexiones.FirstOrDefault(c => c.ConexionID == vuelo.ConexionID).AerolineaID;
            vuelo.AerolineaID = id;
            if (ModelState.IsValid)
            {
                vuelo.Conexiones = new Conexiones();
                vuelo.Conexiones = db.Conexiones.FirstOrDefault(c => c.ConexionID == vuelo.ConexionID);
                db.Vuelo.Add(vuelo);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.ConexionID = new SelectList(db.Conexiones, "ConexionID", "VerInfoCompleta");
            return View(vuelo);

            
        }

        //
        // GET: /Vuelo/Edit/5

        public ActionResult Edit(int id = 0)
        {

            Vuelo vuelo = db.Vuelo.Find(id);
            if (vuelo == null)
            {
                return HttpNotFound();
            }
            ViewBag.AerolineaID = new SelectList(db.Conexiones, "AerolineaID", "CiudadOrigen", vuelo.AerolineaID);
            return View(vuelo);
        }

        //
        // POST: /Vuelo/Edit/5

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Vuelo vuelo)
        {
            if (ModelState.IsValid)
            {
                db.Entry(vuelo).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.AerolineaID = new SelectList(db.Conexiones, "AerolineaID", "CiudadOrigen", vuelo.AerolineaID);
            return View(vuelo);
        }

        //
        // GET: /Vuelo/Delete/5

        public ActionResult Delete(int id = 0)
        {
            Vuelo vuelo = db.Vuelo.Find(id);
            if (vuelo == null)
            {
                return HttpNotFound();
            }
            return View(vuelo);
        }

        //
        // POST: /Vuelo/Delete/5

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Vuelo vuelo = db.Vuelo.Find(id);
            db.Vuelo.Remove(vuelo);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
        //**********************************************************
        public ActionResult VistaEjemplo()
        {
            return View();
        }


      


    }
}